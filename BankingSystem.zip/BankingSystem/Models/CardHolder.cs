﻿using System.ComponentModel.DataAnnotations;

namespace BankingSystem.Models
{
    public class CardHolder
    {
        [Key]
        [Required]
        public int Id { get; set; }

        [Required]
        public string? CardHolderName { get; set; }

        [Required]
        public string?  CardNumber { get; set; }

        [Required]
        public DateTime TransactionDate { get; set; }

        [Required]
        public decimal TransactionAmount { get; set; }
    }
}
