﻿using System.Data;
using Microsoft.EntityFrameworkCore;
using BankingSystem.Models;

namespace BankingSystem.Models
{
    public class AppDBContext: DbContext
    {

        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options) 
        {
            
        }

        public DbSet<CardHolder> CardHolders { get; set; }

        public DbSet<BankingSystem.Models.CardHolderVM>? CardHolderVM { get; set; }
    }
}
