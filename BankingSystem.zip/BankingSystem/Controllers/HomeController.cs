﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using BankingSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace BankingSystem.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        private readonly AppDBContext context;
        public HomeController(AppDBContext context)
        {
            this.context = context;
            
        }


        public IActionResult Index()
        {
            var data = context.CardHolders.ToList();
            return View(data);
        }

        public IActionResult Delete(int id)
        {
            var data = context.CardHolders.Find(id);

            if (data == null)
            {
                NotFound();
            }
            context.CardHolders.Remove(data);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        public IActionResult AddCardHolder()
        {
            return View();
        }

        public IActionResult Details(int id)
        {
            var data = context.CardHolders.Find(id);
            if(data==null)
            {
                return NotFound();
            }
            else {
                return View(data);
            }
            
        }




        [HttpPost]
        public IActionResult AddCardHolder(CardHolderVM model)
        {
            if(ModelState.IsValid)
            {
                var data = new CardHolder()
                {
                    CardHolderName = model.CardHolderName,
                    CardNumber = model.CardNumber,
                    TransactionAmount=model.TransactionAmount,
                    TransactionDate=model.TransactionDate,
                };

                context.Add(data);
                context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            else {
                return View();
            }

            
        }

    
        public IActionResult Edit(int id)
        {
            var model = context.CardHolders.Find(id);
            if (model == null)
            {
                NotFound();
            }
            else
            {
                var result = new CardHolderVM()
                {
                    CardHolderName = model.CardHolderName,
                    CardNumber = model.CardNumber,
                    TransactionAmount = model.TransactionAmount,
                    TransactionDate = model.TransactionDate,

                };
                return View(result);
            }
            return RedirectToAction("Index", "Home");

        }

        [HttpPost]
        public IActionResult Edit(CardHolderVM model,int id)
        {

            if (ModelState.IsValid)
            {

                var result = context.CardHolders.Find(id);
                if (result == null)
                {
                    NotFound();
                }

                result.CardHolderName = model.CardHolderName;
                result.CardNumber = model.CardNumber;
                result.TransactionAmount = model.TransactionAmount;
                result.TransactionDate = model.TransactionDate;

                
                context.CardHolders.Update(result);
                context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            return View();
        }





        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
